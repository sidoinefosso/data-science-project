﻿# INNOSCAPE
[MS2019BGD] Projet Fil Rouge

Auteurs :

	Samuel Cohen-Solal
	Pascal Lim
	Valentin Phetchanpheng
	Jean-Nicolas Vizy


Description :
	Ce répertoire contient les travaux que nous avons réalisés dans le cadre de notre master spécialisé à Telecom Paristech, pour le compte de la société Innoscape. 
	Le code développé vise à :

		- classifier des produits vendus sur des sites d'e-commerce à partir de leur descriptif
		- détecter, parmi une base de produits connus, les produits les plus semblables à un nouveau produit donné


Packages python à installer :
	Le code contenu dans ce répertoire nécessite les packages suivants:

		- itertools
		- numpy
		- matplotlib
		- pandas
		- flask
		- sklearn == 0.20.1
		- scipy
		- Levenshtein
		- treetaggerwrapper (https://www.cis.uni-muenchen.de/~schmid/tools/TreeTagger/)
		- plotly (optionnel)


Contenu :

	- Démonstration : Plusieurs fichiers .py, ainsi qu'une interface html/js/css illustrant le fonctionnement de nos modèles :
		- le corps de la démonstration est contenu dans demo_Innoscape_3.py
		- ce script appelle ensuite différents scripts pour le preprocessing, l'embedding, la classification, le matching

	- Notebooks : plusieurs notebooks jupyter illustrant notre démarche:
		- catégorisation des produits (problématique 1) : comparaison des embeddings, méthodologie de retrait des produits ambigus (classification_NMF.ipynb), visualisation de topics, pipeline général
		- matchin de produits (problémaique 2) : illustration de la démarche (choix des distances, détection des paires de produits identiques, analyse des résultats) et pipeline général

	- Data : les fichiers csv et txt contenant les données

	- Modèles : plusieurs modèles utilisés dans le preprocessing des données (conversions TF-IDF + NMF), la classification, et le matching de produits


Mode d'emploi de la démonstration :

	Si besoin, pour afficher la page html, faire (depuis le répertoire du fichier index.html):
        	python -m http.server 5000
        
    	Puis, exécuter le script demo_Innoscape_3.py en ligne de commande
    	
	Enfin, dans un navigateur, entrer
        	localhost:5000

	Note : pour que la démonstration fonctionne, il faut qu'un modèle de catégorisation et que des modèles de catégorisation et de matching aient été entraînés et soient enregistrés dans le répertoire "models" (cf ci-dessous)

Génération des embeddings :

	- Génération des embeddings pour la catégorisation des produits (Problématique 1) : procédure détaillée dans le notebook Embedding_TopicModeling_Prediction.ipynb
	- Génération des embeddings pour le matching de produits (Problématique 2): procédure détaillée dans le notebook pipeline.ipynb. Attention, un produit ne peut être identifié que si un modèle a été entraîné pour la famille à laquelle il appartient.





