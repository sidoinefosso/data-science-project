from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.externals import joblib
from scipy.sparse import csr_matrix

def embedding(df, path_tfidf, path_nmf, mode='save'):
    """
    Fonction qui permet de:
    1) sauvegarder les modèles d'embeddings (mode ='save') -> sauvegarde des modèles TF-IDF et NMF
    2) transformer les données à partir des modèles d'embeddings (mode = 'load') -> les sorties
    correspondantes sont la matrice suite à la tranformation TF-IDF/NMF et la liste du vocabulaire
    
    Inputs:
        df : dataframe : dataframe contenant les données à traiter
        path_tfidf : string : chemin vers le répertoire où est stocké l'objet TfidfVectorizer pour la vectorisation du texte (en mode 'save', répertoire où l'objet fitté est enregistré à la fin de l'entraînement)
        path_nmf : string : chemin vers le répertoire où est stocké l'objet NMF pour l'embedding du texte (en mode 'save', répertoire où l'objet fitté est enregistré à la fin de l'entraînement)
        mode : string : si 'save', la fonction fitte un objet TfidfVectorizer et un objet NMF pour l'embedding du texte contenu dans df ; si 'load', charge les deux objets et convertit le texte.
    
    Outputs:
        X : ndarray : textes convertis en NMF
        vocab : liste : liste des mots correspondants aux coordonnées des vecteurs issus du TF-IDF
        
    """
    # Concaténation des données pertinentes
    for i in range(len(df.columns)):
        if i == 0:
            df.loc[:, "concat"] = df.iloc[:, i]
        else:
            df.loc[:, "concat"] += " " + df.iloc[:, i]
    # Transformation tf-idf 
    if mode == 'save':
        vectorizer = TfidfVectorizer(lowercase=False, max_features = 500) 
        tf_idf = csr_matrix(vectorizer.fit_transform(df["concat"]))
        vocab = vectorizer.get_feature_names()
        joblib.dump(vectorizer, path_tfidf) # sauvegarde du modèle
    elif mode == 'load':
        vectorizer = joblib.load(path_tfidf)
        tf_idf = csr_matrix(vectorizer.transform(df["concat"]))
        vocab = vectorizer.get_feature_names()
    else:
        print("Choisir un mode entre 'save' et 'load'.")
        return
    # Transformation NMF
    if mode == 'save':
        nmf = NMF(n_components=250, alpha=.1, l1_ratio=.5).fit(tf_idf)
        joblib.dump(nmf, path_nmf) # sauvegarde du modèle
        return
    elif mode == 'load':
        nmf = joblib.load(path_nmf)
        X = nmf.transform(tf_idf)
        return X, vocab
    else:
        print("Choisir un mode entre 'save' et 'load'.")
        return
    
def convert_text(df, column, path_tfidf, path_nmf):
    """
    Met en forme les données issues de la méthode embedding en les convertissant en dataframe.
    Inputs:
        df : dataframe : dataframe où sont stockés les textes à convertir
        column : string : nom de la colonne de df où sont stockés les textes
        ppath_tfidf : string : chemin vers le répertoire où est stocké l'objet TfidfVectorizer pour la vectorisation du texte (en mode 'save', répertoire où l'objet fitté est enregistré à la fin de l'entraînement)
        path_nmf : string : chemin vers le répertoire où est stocké l'objet NMF pour l'embedding du texte (en mode 'save', répertoire où l'objet fitté est enregistré à la fin de l'entraînement)
    
    Output:
        df_aug : dataframe : copie de df, contenant en plus les coordonnées des textes dans l'embedding spécifié
    """
# =============================================================================
#     col_names = ['topic_' + str(i) for i in range(X.shape[1])]
#     df = pd.DataFrame(X, index=index).rename(columns=dict(zip(range(X.shape[1]), col_names)))
#     df['label'] = labels
# =============================================================================
    
    df_nmf, _ = embedding(pd.DataFrame(df['Description_clean']), '../../models/tfidf_top500_base', '../../models/nmf_250topics_base', mode='load')
    topics = ["topic_"+str(i) for i in range(250)]
    df_topics = pd.DataFrame(df_nmf, columns=topics).set_index(df.index)
    df_aug = pd.concat((df, df_topics), axis=1)
    return df_aug
  