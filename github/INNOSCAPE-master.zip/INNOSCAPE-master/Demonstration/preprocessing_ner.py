# Librairies
import numpy as np
import re

# Liste des attributs
list_attributes = ['Volume', 'Mesure', 'Poids', 'AmpereHeure', 'NewtonMetre', 'Watt', 'Volt', 'Rpm', 'Joules', 'Metre2']

# Dictionnaire de regex pour chaque attribut (modifiable)
dico_regex = {'Poids':r"(\b[\d.,]+)\s*(g|grammes|kg)\b", 
              'Mesure':r"(\b[\d.,]+)\s*(mm|cm|m|mètres|mètre)\b",
              'Volume':r"(\b[\d.,]+)\s*(ml|cl|l|litres|litre|cm³)\b",
              'Volt':r"(\b[\d.,]+)\s*(v|volts|volt)\b",
              'Watt':r"(\b[\d.,]+)\s*(w|watts|watt)\b",
              'AmpereHeure':r"(\b[\d.,]+)\s*(ah)\b",
              'NewtonMetre':r"(\b[\d.,]+)\s*(nm)\b",
              'Rpm':r"(\b[\d.,]+)\s*(rpm)\b",
              'Joules':r"(\b[\d.,]+)\s*(j|joules)\b",
              'Metre2':r"(\b[\d.,]+)\s*(m²)\b",
              'Batterie':r"(\b[\d.,]+)\s*(batteries|batterie)\b",
              'Couleur':r"\b(gris|noir|marron|beige|rouge|blanc|bleu|vert|argent|jaune|rose|violet|orange|multicolore)\b",
              'Modele':r"[a-z0-9]+[-]?[0-9]+[a-z0-9]+(?= )",
              'All':r"(\b[\d.,]+)\s*(g|gramme|grammes|kg|mm|cm|m|mètre|mètres|ml|cl|l|litre|litres|v|volt|volts|w|watt|watts|ah|nm|rpm|j|joule|joules|cm³|m²)\b"}


# Preprocessing pour récupérer les attributs : Poids, Mesure, Volume, Couleur...
def ner_attributs(df, name_col, dico_regex):
    df['Poids'] = df[name_col].apply(lambda x: re.search(dico_regex['Poids'], x).group() if re.search(dico_regex['Poids'], x) is not None else '')
    df['Mesure'] = df[name_col].apply(lambda x: re.search(dico_regex['Mesure'], x).group() if re.search(dico_regex['Mesure'], x) is not None else '')
    df['Volume'] = df[name_col].apply(lambda x: re.search(dico_regex['Volume'], x).group() if re.search(dico_regex['Volume'], x) is not None else '')
    df['Volt'] = df[name_col].apply(lambda x: re.sub(dico_regex['Volt'], r"\1", re.search(dico_regex['Volt'], x).group()) if re.search(dico_regex['Volt'], x) is not None else '')
    df['Watt'] = df[name_col].apply(lambda x: re.sub(dico_regex['Watt'], r"\1", re.search(dico_regex['Watt'], x).group()) if re.search(dico_regex['Watt'], x) is not None else '')
    df['AmpereHeure'] = df[name_col].apply(lambda x: re.sub(dico_regex['AmpereHeure'], r"\1", re.search(dico_regex['AmpereHeure'], x).group()) if re.search(dico_regex['AmpereHeure'], x) is not None else '')
    df['NewtonMetre'] = df[name_col].apply(lambda x: re.sub(dico_regex['NewtonMetre'], r"\1", re.search(dico_regex['NewtonMetre'], x).group()) if re.search(dico_regex['NewtonMetre'], x) is not None else '')
    df['Rpm'] = df[name_col].apply(lambda x: re.sub(dico_regex['Rpm'], r"\1", re.search(dico_regex['Rpm'], x).group()) if re.search(dico_regex['Rpm'], x) is not None else '')
    df['Joules'] = df[name_col].apply(lambda x: re.sub(dico_regex['Joules'], r"\1", re.search(dico_regex['Joules'], x).group()) if re.search(dico_regex['Joules'], x) is not None else '')
    df['Metre2'] = df[name_col].apply(lambda x: re.sub(dico_regex['Metre2'], r"\1", re.search(dico_regex['Metre2'], x).group()) if re.search(dico_regex['Metre2'], x) is not None else '')
    df['Batterie'] = df[name_col].apply(lambda x: re.sub(dico_regex['Batterie'], r"\1", re.search(dico_regex['Batterie'], x).group()) if re.search(dico_regex['Batterie'], x) is not None else '')
    df['Couleur'] = df[name_col].apply(lambda x: re.search(dico_regex['Couleur'], x).group() if re.search(dico_regex['Couleur'], x) is not None else '')
    return df


# Preprocessing pour retirer les attributs (unités de mesure, caractéristiques) et marque de la description
def preprocessing_description(df, name_col, dico_regex, unique_brand):
    df['Description'] = df[name_col].apply(lambda x: re.sub(dico_regex['All'], "", x))
    df['Description'] = df['Description'].apply(lambda x: re.sub(dico_regex['Couleur'], "", x))
    
    # Retirer les marques
    regex = r'(' + r'|'.join(unique_brand) + r')'
    df['Description'] = df['Description'].apply(lambda x: re.sub(regex, "", x))
    return df


# Normaliser les unités de mesure et convertir en float
# Exemple : Poids en gramme, Mesure en mètre, Volume en litre etc
def normalization_unit(df, name_col):    
    dico = {'Poids':{'g':1, 'gramme':1, 'grammes':1, 'kg':1000}, 'Mesure':{'mm':0.001, 'm':1, 'mètre':1, 'mètres':1, 'cm':0.01}, 'Volume':{'ml':0.001, 'cl':0.01, 'l':1, 'litre':1, 'litres':1, 'cm³':0.001}}
    dico_regex = {'Poids':'(g|gramme|grammes|kg)', 'Mesure':'(mm|cm|m|mètre|mètres)', 'Volume':'(ml|cl|l|litre|litres|cm³)'}
    if name_col in dico:
        df[name_col] = df[name_col].apply(lambda x: float(re.search('\d+', x).group())*dico[name_col][re.search(dico_regex[name_col], x).group()] if re.search("\d+", x) and re.search(dico_regex[name_col], x) is not None else '')
    
    # Preprocessing pour conversion des unités de mesure et remplir les valeurs vides et nulles par NaN
    df[name_col] = df[name_col].apply(lambda x: np.NaN if x == "" else x)
    df[name_col] = df[name_col].apply(lambda x: float(x.replace(',','.')) if isinstance(x, str) else x)
    df[name_col] = df[name_col].apply(lambda x: x if x != 0 else np.NaN)
    return df


# Récupérer les marques (uniformiser, remplir les marques manquantes)
def ner_brand(df, name_col, brand_col, unique_brand): 
    regex = r'\b(' + r'|'.join(unique_brand) + r')\b'
    regex2 = r'(' + r'|'.join(unique_brand) + r')'
    
    # Marque pour chaque produit
    df['brand'] = df[name_col].apply(lambda x: re.search(regex, x).group() if re.search(regex, x) is not None else '')
    
    # Gestion sans marque suite à la première regex
    index_no_brand = df[df.brand == ''].index.tolist()
    for index in index_no_brand:
        if re.search(regex2, df[brand_col].iloc[index]) is not None:
            df['brand'].iloc[index] = re.search(regex2, df[brand_col].iloc[index]).group() 
        elif re.search(regex2, df[name_col].iloc[index]) is not None:
            df['brand'].iloc[index] = re.search(regex2, df[name_col].iloc[index]).group() 
        else:
            df['brand'].iloc[index] = ''
    
    # Cas spécial : black and decker
    df['brand'] = df['brand'].apply(lambda x: 'blackanddecker' if x in ['black & decker','black and decker', 'black + decker'] else x)
    return df


# Extraire l'attribut modèle et retirer le modèle de la description
def ner_model_preprocessing(df, dico_regex):    
    df['model'] = df['Description'].apply(lambda x: re.search(dico_regex['Modele'], x).group() if re.search(dico_regex['Modele'], x) is not None else '')
    
    # Clean description : retirer les modèles
    df['Description'] = df['Description'].apply(lambda x: re.sub(dico_regex['Modele'], "", x))
    return df


def lowercase(df, name_col):
    df[name_col] = df[name_col].str.lower()
    return df


def ner_preprocessing(df, raw_description, raw_brand, unique_brand, list_attributes=list_attributes, dico_regex=dico_regex):
    """
    Fonction de preprocessing globale
    Extraction des attributs, normalisation des unités de mesure, gestion des marques
    
    Param :
        df : Dataframe à modifier
        raw_description : Colonne description
        raw_brand : Colonne marque
        new_description : Nouvelle colonne marque
        new_brand : Nouvelle colonne marque
        model : Colonne modèle
        unique_brand : Liste des marques
        stop_words : Stop words
        
    Return : Dataframe
    """
    # Lettre en minuscule
    df = lowercase(df, raw_description)
    df = lowercase(df, raw_brand)
    
    # Extraction attributs, marques et modèles
    # Preprocessing description
    # Normalisation des unités de mesures
    df = ner_attributs(df, raw_description, dico_regex)
    df = preprocessing_description(df, raw_description, dico_regex, unique_brand)
    
    for attribute in list_attributes:
        df = normalization_unit(df, attribute)
   
    df = ner_brand(df, raw_description, raw_brand, unique_brand)
    df = ner_model_preprocessing(df, dico_regex)
    
    return df
    
    


