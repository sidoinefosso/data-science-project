# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 11:13:33 2019

@author: JN
"""

# sélection des produits pertinents pour l'entraînement d'un classifieur

import pandas as pd
import numpy as np
from collections import Counter


def get_top_topics(row, num_topics, num_top_topics):
    cols_to_fetch = ['topic_' + str(i) for i in range(num_topics)]
    top_topics_idx = np.argsort(-np.array(row[cols_to_fetch]))[:num_top_topics]
    top_topics_cols = ['topic_' + str(i) for i in top_topics_idx]
    top_topics_weights = row[top_topics_cols].values
    return [top_topics_idx, top_topics_weights]


def unpack_top_topics(df, top_topics_col, total_weights_col, num_top_topics):
    col_names1 = ['top_topic_' + str(i) for i in range(1, num_top_topics + 1)]
    col_names2 = [
        'top_topic_' + str(i) + '_relative_weight'
        for i in range(1, num_top_topics + 1)
    ]
    df2 = df.copy()
    for i in range(len(col_names1)):
        df2[col_names1[i]] = df[top_topics_col].apply(lambda x: x[0][i])
        df2[col_names2[i]] = df[top_topics_col].apply(lambda x: x[1][i])
        df2[col_names2[i]] = df2[col_names2[i]] / df2[total_weights_col]
    return df2


def get_nb_relevant_items(row, threshold):
    """ Donne, pour un produit donné, et un seuil de poids donné, le nombre de topics pertinents 
        Inputs : 
            row : un descriptif produit (ligne de la base produits)
            threshold : float : seuil d'importance
        Outputs : nombre de topics significatifs (int)
    """
    counter = 1
    for i in range(1, row.shape[0]):
        if row.iloc[i] / row.iloc[i - 1] >= threshold:
            counter += 1
        else:
            break

    return counter


class ItemSelector:
    """
    Attributs:
        X : nd-array : coordonnées des produits obtenues par NMF
        labels : ndarray : labels des produits
        index : pandas Index object : indices des produits dans le dataframe de départ
        min_count : int : effectif minimal d'une famille pour l'entraînement (défaut : 20)
        max_top_topics : int : nombre maximal de topics principaux extraits par la méthode top_topic_extraction (défaut : 10)
        topics_by_fam : dataframe : descriptif des trois principaux topics par famille, avec leur poids
        alpha : float (compris entre 0 et 1) : seuil d'importance relative pour deux topics consécutifs
        max_relevant_topics : int : nombre maximum de topics significatifs acceptés

    """

    def __init__(self,
                 min_count=20,
                 max_top_topics=10,
                 alpha=0.7,
                 max_relevant_topics=3):
        self.min_count = min_count
        self.max_top_topics = max_top_topics
        self.alpha = alpha
        self.max_relevant_topics = max_relevant_topics
        self.X = None
        self.labels = None
        self.index = None
        self.df = None
        self.col_names = None
        self.main_fams = None
        self.X_main_fams = None

    def setting(self, X, labels, index):
        self.X = X
        self.labels = labels
        self.index = index

    def data_formatting(self):
        self.col_names = ['topic_' + str(i) for i in range(self.X.shape[1])]
        self.df = pd.DataFrame(self.X, index=self.index).rename(columns=dict(zip(range(self.X.shape[1]), self.col_names)))
        self.df['label'] = self.labels
        
    def fam_selection(self):
        fam_counts = Counter(self.labels)
        self.main_fams = [ k for k, v in fam_counts.items() if v >= self.min_count]
        main_fams_idx = [i for i in range(self.labels.shape[0]) if self.labels[i] in self.main_fams]
        self.df = self.df.iloc[main_fams_idx]

    def top_topic_extraction(self):
        self.df['total_weights'] = np.sum(self.df, axis=1)
        num_topics = self.X.shape[1]
        num_top_topics = self.max_top_topics
        self.df['top_top'] = self.df.apply(get_top_topics,
                                           args=([num_topics, num_top_topics]),
                                           axis=1)
        self.df = unpack_top_topics(self.df, 'top_top', 'total_weights',
                                    num_top_topics)
        self.df.drop('top_top', axis=1, inplace=True)

    def get_nb_relevant_topics(self):
        col_list = [
            'top_topic_' + str(i) + '_relative_weight'
            for i in range(1, self.max_top_topics + 1)
        ]
        self.df['nb_relevant_topics'] = self.df[col_list].apply(
            get_nb_relevant_items, args=([self.alpha]), axis=1)


    def fit(self, X, labels, index):
        self.data_formatting()
        self.fam_selection()
        self.top_topic_extraction()
        self.get_nb_relevant_topics()

    def transform(self):
        res = self.df[self.df['nb_relevant_topics'] <= self.max_relevant_topics]
        return res[self.col_names], res['label']

    def fit_transform(self, X, labels, index):
        self.setting(X, labels, index)
        self.data_formatting()
        self.fam_selection()
        self.top_topic_extraction()
        self.get_nb_relevant_topics()
        res = self.df[self.df['nb_relevant_topics'] <= self.max_relevant_topics]
        return res[self.col_names], res['label']
                       
    
#interprétation de l'embedding

# import pandas as pd
# import numpy as np
# from collections import Counter

# def get_nb_relevant_items(row, threshold):
#     """ donne, pour un topic donné, le nombre de mots pertinents """
#     counter = 1
#     for i in range(1, row.shape[0]):
#         if row.iloc[i] / row.iloc[i - 1] >= threshold:
#             counter += 1
#         else:
#             break     
#     return counter

# def get_top_words(row, num_words, num_top_words):
#     """ renvoie la liste des mots, triés par poids décroissants, et les poids """
#     cols_to_fetch = [i for i in range(num_words)]
#     top_words_idx = np.argsort(-np.array(row[cols_to_fetch]))[:num_top_words]
#     top_words_cols = [i for i in top_words_idx]
#     top_words_weights = row[top_words_cols].values
#     return [top_words_idx,top_words_weights]

# def unpack_top_words(df, top_words_col,total_weights_col ,num_top_words):
#     """ extrait les k premiers mots d'un topic et leurs poids respectifs dans des colonnes distinctes """
#     col_names1 = ['top_word_'+str(i) for i in range(1,num_top_words+1)]
#     col_names2 = ['top_word_'+str(i)+'_relative_weight' for i in range(1,num_top_words+1)]
#     df2 = df.copy()
#     for i in range(len(col_names1)):
#         df2[col_names1[i]] = df[top_words_col].apply(lambda x: x[0][i])
#         df2[col_names2[i]] = df[top_words_col].apply(lambda x: x[1][i])
#         df2[col_names2[i]] = df2[col_names2[i]]/df2[total_weights_col]
#     return df2

# class TopicSelector:
    
#     """
#     Attributs:
#         components : objet nmf.components : expression des vecteurs de base d'un embedding nmf dans un vocabulaire donné
#         vocabulary : objet tf_idf.vectorizer.vocabulary : vocabulaire utilisé lors de la transformation tf-idf d'un corpus
#         n_components : int : nombre de mots principaux utilisés pour l'interprétation des composantes de la nmf (défaut : 10)
        
#         topic_explanation : dict : dictionnaire des principaux mots par topic, avec leurs poids
        
        
#     """
    
#     def __init__(self, components, vocabulary, max_features_tfidf ,n_words=10):
#         self.components = components
#         self.vocabulary = vocabulary
#         self.n_words = n_words
#         self.max_features_tfidf = max_features_tfidf
#         self.topic_explanation = None
        
# #     def get_topic_explanation(self):
# #         voc_reverse = dict(zip(self.vocabulary.values(),self.vocabulary.keys()))
# #         topic_description = {}
# #         weights = []
# #         for i in range(self.components.shape[0]):
# #             top_components = np.argsort(-self.components[i,:])[:self.n_words]
# #             weights.append(self.components[i,self.n_words])
# #             weights = self.components[i,self.n_words]
# #             words = [voc_reverse[c] for c in top_components]
# #             explanation = dict(zip(words,weights))
# #             topic_description[i] = explanation 
# #         self.topic_explanation = topic_description

#     def data_formatting(self):
#         topic_components = pd.DataFrame(self.components)
#         topic_components['total'] = np.sum(topic_components, axis=1)
#         empty_topics = topic_components[topic_components['total']==0].index
#         topic_components.drop(empty_topics, axis=0, inplace=True)
        
#         for i in range(self.n_words):
#             topic_components[i] = topic_components[i]/topic_components['total']
        
#         dfw = topic_components.copy()
#         dfw['top_words'] = dfw.apply(get_top_words, args=([self.max_features_tfidf, self.n_words]), axis=1)
#         dfw = unpack_top_words(dfw,'top_words','total', num_top_words)
#         dfw.drop('top_words', axis=1, inplace=True)
        
        
        
#         self.df = pd.DataFrame(self.X, index=self.index).rename(columns=dict(zip(range(X.shape[1]),['topic_'+str(i) for i in range(X.shape[1])])))

