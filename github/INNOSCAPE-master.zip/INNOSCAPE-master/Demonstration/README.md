# INNOSCAPE
[MS2019BGD] Projet Fil Rouge

Auteurs :

	Samuel Cohen-Solal

	Pascal Lim

	Valentin Phetchanpheng

	Jean-Nicolas Vizy


Description :
	Ce r�pertoire contient les travaux que nous avons r�alis�s dans le cadre de notre master sp�cialis� � Telecom Paristech, pour le compte de la soci�t� Innoscape. 
	Le code d�velopp� vise � :

		- classifier des produits vendus sur des sites d'e-commerce � partir de leur descriptif

		- d�tecter, parmi une base de produits connus, les produits les plus semblables � un nouveau produit donn�


Packages python � installer :
	Le code contenu dans ce r�pertoire n�cessite les packages suivants:

		- itertools

		- numpy

		- matplotlib

		- pandas

		- flask

		- sklearn

		- scipy

		- Levenshtein

		- treetaggerwrapper


Contenu :

	- D�monstration : Plusieurs fichiers .py, ainsi qu'une interface html/js/css illustrant le fonctionnement de nos mod�les

	- Notebooks : plusieurs notebooks jupyter illustrant notre d�marche

	- Data : les fichiers csv et txt contenant les donn�es, notamment:
		
	- Mod�les : plusieurs mod�les utilis�s dans le preprocessing des donn�es (conversions TF-IDF + NMF), la classification, et le matching de produits

Mode d'emploi




