import requests
from bs4 import BeautifulSoup
import pandas as pd
import json
import urllib.parse
import re
import time

#Paramétrage des variables
website = "https://www.idealo.fr/type/4892210118677.html"


def _handle_request_result(request_result):
    if request_result.status_code == 200:
        return True
    else:
        return False


def make_soup(res):
    html_doc = res.content
    soup = BeautifulSoup(html_doc, "html.parser")
    return soup

    
def get_url(product_name):
    res = requests.get(url_page)
    if _handle_request_result(res):
        soup = make_soup(res)
    else:
        print("Error request")
        return
    products = soup.main.find_all('span', class_='productOffers-listItemTitleInner one-line-limit', recursive=True)
    products = [product.text.replace('\n\t\t\t\t\t\t\t', '') for product in products]
    return products


def get_form(soup):
    form = soup.find(name='form', action=re.compile(r'https://www.idealo.fr/prechcat.html'))
    return form


def get_action(form, base_url):
    action = form['action']
    # action is relative url, convert it to absolute url
    abs_action = urllib.parse.urljoin(base_url, action)
    return abs_action


def get_form_data(form, product):
    data = {}
    for inp in form('input'):
        # if the value is None, we put the product name to this field
        data[inp['name']] = inp['value'] or product
    return data


if __name__ == '__main__':
    url = 'https://www.idealo.fr/'
    res = requests.get(url)
    df = pd.DataFrame(columns=["index_data", "product_name", "product_price", "currency", "voucher", "shop_name", "url_origin", "url_image", "id_page"])
    df_initial = pd.read_csv("../Data/df_train.csv")
    j = 0 # iteration variable to fill data 
    if _handle_request_result(res):
        soup = make_soup(res)
        form = get_form(soup)
        action = get_action(form, url)
        for i in range(2900, 3000): #0-2000 non compris : Pascal, 2000-
            product_name = df_initial.productseller_name[i]
            data = get_form_data(form, product_name)
            # make request to the action using data
            res_post = requests.post(action, data=data)
            soup_post = make_soup(res_post)
            offers = soup_post.find_all('a', class_="offerList-itemWrapper", href=True)
            if len(offers) == 1:
                id_page = offers[0]["href"]
                res_get = requests.get(url + id_page)
                soup_get = make_soup(res_get)
                products = soup_get.find_all('a', class_="productOffers-listItemTitle", href=True)
#                 url_image = soup_get.find("main", {"class": "pageContent-wrapper"}).div['data-recentproducts']
#                 url_image = json.loads(url_image)['productImage']
                for a in products:
                    a_product = json.loads(a["data-gtm-payload"])
                    dict_product = {"index_data": df_initial['Unnamed: 0'][i], "product_name": a.span.text.replace('\n\t\t\t\t\t\t\t', ''), "product_price": a_product["product_price"], "currency": a_product["currency"], "voucher": a_product["voucher"], "shop_name": a_product["shop_name"], "url_origin": a["href"], "url_image": 0, "id_page":id_page}
                    df.loc[j] = pd.Series(dict_product)
                    j += 1
            time.sleep(0.5)
        df.to_csv("similar_products_15.csv")     
    else:
        print("Error request")
        print(res)
    

# print(get_products(website))
