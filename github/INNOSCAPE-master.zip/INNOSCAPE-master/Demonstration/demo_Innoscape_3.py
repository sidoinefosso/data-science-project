# -*- coding: utf-8 -*-
"""
Created on Mon Jun 17 10:25:54 2019

@author: JN
"""

from flask import Flask, render_template, session, request, redirect, flash, url_for

from load_data import *
from preprocessing import *
from embedding import *
from item_selection import *
from product_categorization import *
from sklearn.metrics import accuracy_score, f1_score, roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from product_categorization_2 import *
from matrice_similarity_2 import *
from preprocessing_ner_2 import *
#from preprocessing_2 import *
from load_data_2 import *
from embedding_2 import *


app = Flask(__name__)
app.secret_key = "TODO: mettre une valeur secrète ici"

#%% Définition des chemins vers les répertoires où sont stockés les modèles
# et les données (à adapter en fonction de chaque poste)

"""
    Si besoin, pour afficher la page html, faire (depuis le répertoire du
    fichier index.html):
        python -m http.server 5000
        
    Puis, exécuter le script demo_Innoscape.py en ligne de commande
    Enfin, dans un navigateur, entrer
        localhost:5000
"""


data_path = "../Data/"
model_path = "../models/"

@app.route('/', methods=['GET'])

# PROBLEMATIQUE 1   
 # =============================================================================
def index():
    return render_template('index.html', message="TEST !")

@app.route('/new', methods=['POST'])
def new_game():
    session['description'] = request.form['description']
    session['categorie'] = request.form['categorie']
    session['marque'] = request.form['marque']
    session['prix'] = request.form['prix']
    return redirect('classification')

@app.route('/classification', methods=['GET','POST'])
def classification(thresholding='default'):
    # on commence par caster les données issues du formulaire dans un format
    #adapté (dataframe)
    df = pd.DataFrame({'description':session['description'],
                   'marque':session['marque'],
                   'categorie':session['categorie'],
                   'prix':session['prix']},index=['demo'])
    
    #preprocessing des données textuelles
    stop_words = union_set(data_path+"stop_words.txt",data_path+"marques.txt") 
    df_process_train = preprocessing(df, 
                                     ['description','categorie'], 
                                     stop_words, tag_dir="C:/TreeTagger")
        
    #embedding
    X, vocab = embedding(df_process_train, model_path+'tfidf_top500_base', 
                     model_path+'nmf_250topics_base', mode='load')
    
    #classification
    prediction, soft_proba = categorization(X, mode='prediction', 
                                        thresholding='default', 
                                        path=model_path+'categorization_model')
    
    #explication de la catégorie trouvée
    label_explanation = pd.read_excel(data_path+'reference_innoscape.xlsx')[
            ['label', 'innoscape_ref_productfamily_seller.1']]
    family_dict = dict(zip(label_explanation.label.values, 
                           label_explanation['innoscape_ref_productfamily_seller.1'].values))

    #filtrage des prédictions incertaines
    session['probability'] = int(100*np.max(soft_proba))
    #session['family_code'] = prediction[0]
    
# =============================================================================
#     if session['probability'] < 0.25:
#         session['family_text'] = 'a valider'
#         session['probability'] = prediction[0]
#     else :
#         session['family_text'] = family_dict[prediction[0]]
#         session['probability'] = int(100*np.max(soft_proba))
# =============================================================================
    
    if session['probability'] < 25:
        session['family_text'] = 'à valider'
    else :
        session['family_text'] = family_dict[prediction[0]]
        
# PROBLEMATIQUE 2    
 # =============================================================================
    category = prediction[0]
    if category != 2000:
        # On load les produits de la base de données sans id_page + corrections
        df = pd.read_csv(data_path+'data_similary_products_computed.csv')
        df = df.iloc[1:,:]
        list_cat = ['Couleur', 'model', 'brand']
        for cat in list_cat:
            df[cat].fillna('', inplace=True)
        df['id_product'] = df['id_product'].apply(lambda x: str(x))

        # Dictionnaire de correspondance : id produit --> produit
        df_ref = load_data2(data_path+'data_similary_products.csv')
        id_to_product = df_ref[['id_product', 'id_page']]
        id_to_product = id_to_product.set_index('id_product')['id_page'].to_dict()

        # On récupère le produit à identifier
        df_product = pd.DataFrame({"productseller_name":session['description'], 
                                   "brand_seller":session['marque'], 
                                   "product_price":float(session['prix']), 
                                   "label":category, "id_product":"demo"}, 
                                    index=[0])

        # Preprocessing & NER du produit à identifier
        unique_brand = open(data_path+'unique_brand.txt').read().split('\n')
        stop_words = load_txt(data_path+'stop_words.txt')
        tag_dir = "C:/TreeTagger"
        df_product = ner_preprocessing(df_product, 
                                       'productseller_name', 
                                       'brand_seller', 
                                       unique_brand)
        df_description = preprocessing(df_product, 
                                       ['Description'], 
                                       stop_words, 
                                       tag_dir)

        # Garder les colonnes utiles 
        col = ['label','id_product','productseller_name','brand','Description',
               'Volume','Mesure','Poids',
               'AmpereHeure','NewtonMetre','Watt','Volt','Rpm','Joules',
               'Metre2','Couleur','product_price','model',
               'Description_clean']   
        df_product = df_product[col]

        # Charger embedding et transformer les données dans l'espace embedding
        X2_nmf, vocab = embedding2(df_description, 
                                   model_path+'tfidf_max_vocab_base_2', 
                                   model_path+'nmf_250topics_base_2', 
                                   mode='load') 

        # Concat le produit à identifier et les données de la base
        # Matrice de similarité
        topics = ["topic_"+str(i+1) for i in range(250)]
        df_topics = pd.DataFrame(X2_nmf, columns=topics).set_index(df_product.index)
        df_product = pd.concat((df_product, df_topics), axis=1)
        df = pd.concat((df_product, df), axis=0, ignore_index=True)

        threshold_na = 0.6
        X, pair_id_product = get_matrix_similarity(df, category, 
                                                   threshold_na, topics, 
                                                   mode='prediction', nb=1)

        # Prédiction du classifieur
        prediction, soft_proba = categorization2(X, 
                                                 mode='prediction',
                                                 thresholding='default',
                                                 path=model_path+'categorization_model_'+str(category))

        # Résultats
        result = pd.DataFrame()
        result['predict_proba_1'] = soft_proba[:,1]
        result['paire_id_product'] = pair_id_product
        result['product'] = result['paire_id_product'].apply(lambda x: id_to_product[x.split('_')[1]])
        top3 = result.nlargest(3, 'predict_proba_1')[['predict_proba_1', 'product']]

        top_proba = []
        top_product = []
        for proba, product in zip(top3['predict_proba_1'], top3['product']):
            if proba > 0.4:
                top_proba.append(proba)
                top_product.append(product)
            else:
                pass

        session['proba1'] = int(top_proba[0]*100)
        session['product1'] = top_product[0]

        session['proba2'] = int(top_proba[1]*100)
        session['product2'] = top_product[1]

        session['proba3'] = int(top_proba[2]*100)
        session['product3'] = top_product[2]
        return redirect('game')
    else:
        flash("Catégorie à valider, choisir une autre catégorie")
        return redirect('index')


@app.route('/game', methods=['GET'])
def game():
    #flash('Test')
    return render_template('page2.html')

if __name__ == '__main__':
    app.run(debug=True)
