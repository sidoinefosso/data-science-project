# Librairies
import numpy as np
import Levenshtein
from sklearn.metrics.pairwise import cosine_similarity
from scipy.special import binom

# Liste des attributs de base et spécifiques
list_attributes_standard = ["product_price", "Couleur", "brand", "model"]
list_units = ["Volt", "Watt", "AmpereHeure", "NewtonMetre", "Poids", "Mesure", "Volume", 'Rpm', 'Joules', 'Metre2']

# Boolean distance for categorical attributes
def boolean_distance(attr1, attr2):
    if attr1 == "" or attr2=="":
        return 0.5
    elif attr1 == attr2:
        return 0
    else:
        return 1
    
# Euclidian distance 
def euclidian_distance_customed(price, price_ref):
    return np.sqrt(((price-price_ref)/(price_ref*price))**2)

# Select the attributes (units/color) if there are enough data and fill data with median
def select_fill_attributes(df, list_attributes, seuil_ratio_na):
    for attribute in list_attributes:
        ratio_na = df[df[attribute].isna()].shape[0] / df.shape[0]
        if ratio_na < seuil_ratio_na:
            median = df[attribute].value_counts().describe().loc["50%"]
            df[attribute].fillna(median, inplace=True)
        else:
            df.drop(attribute, axis=1, inplace=True)
    return df

# Compute cosine distance for pairwise products
def cosine_pairwise(df, nb):
    list_cosine = []
    for i in range(df.shape[0]-1):
        product_ref = np.array(df.iloc[i,:]).reshape(1,-1)
        list_cosine += cosine_similarity(product_ref, df.iloc[i+1:,:].values)[0].tolist()
    return list_cosine

# Compute distance for pairwise products
def distance_pairwise(df):
    distances = np.zeros((int(binom(df.shape[0], 2)), df.shape[1]))
    list_features = df.columns
    for j in range(len(list_features)):
        # Iteration
        k = 0
        for i in range(df.shape[0]-1):
            product_ref = df.iloc[i, j]
            products_to_compare = df.iloc[i+1:, j]
            for product in products_to_compare:
                distances[k, j] = dict_metrics[list_features[j]](product_ref, product)
                k += 1
    return distances

# Pair of label to determine what are the products compared
def label_pairwise(df):
    list_id_page = []
    for i in range(df.shape[0]-1):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        list_id = product_ref + '_' + products_to_compare
        list_id_page += list_id.tolist()
    return list_id_page

# Id of product (Index)
def product_id(df):
    list_id = []
    for i in range(df.shape[0]-1):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        for product in products_to_compare:
            list_id.append(product_ref)
    return list_id

# Label : 1 if products are similar, 0 if products are different
def create_labels(labels):
    list_labels = []
    for i in range(len(labels)-1):
        product_ref = labels[i]
        products_to_compare = labels[i+1:]
        for product in products_to_compare:
            if product_ref == product:
                list_labels.append(1)
            else:
                list_labels.append(0)
    return list_labels

# Compute cosine distance for pairwise products
def cosine_pairwise_2(df, nb):
    list_cosine = []
    for i in range(nb):
        product_ref = np.array(df.iloc[i,:]).reshape(1,-1)
        list_cosine += cosine_similarity(product_ref, df.iloc[i+1:,:].values)[0].tolist()
    return list_cosine

def distance_pairwise_3(df, nb):
    distances = np.zeros((int(df.shape[0]*nb - ((nb*(nb+1))/2)), df.shape[1]))
    list_features = df.columns
    for j in range(len(list_features)):
        # Iteration
        k = 0
        for i in range(nb):
            product_ref = df.iloc[i, j]
            products_to_compare = df.iloc[i+1:, j]
            for product in products_to_compare:
                distances[k, j] = dict_metrics[list_features[j]](product_ref, product)
                k += 1
    return distances

def label_pairwise_2(df, nb):
    list_id_page = []
    list_ref = [] 
    for i in range(nb):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        list_id = product_ref + '_' + products_to_compare
        list_id_page += list_id.tolist()
    return list_id_page


# Dictionnary of metrics used to compare each attribute 
dict_metrics = {"product_price": euclidian_distance_customed, "Couleur": boolean_distance, 
                "brand": boolean_distance, "model": Levenshtein.distance, 
                "Volt": euclidian_distance_customed, "Watt": euclidian_distance_customed,
                "AmpereHeure": euclidian_distance_customed, "NewtonMetre": euclidian_distance_customed,
                "Poids": euclidian_distance_customed, "Mesure": euclidian_distance_customed,
                "Volume": euclidian_distance_customed, "Rpm": euclidian_distance_customed, 
                "Joules": euclidian_distance_customed, "Metre2": euclidian_distance_customed}


def get_matrix_similarity(df, category, seuil_ratio_nan, list_topics, mode, nb=None, list_attributes_standard=list_attributes_standard, list_units=list_units):
   
    """
    Fonction pour créer la matrice contenant les features de similarité par rapport à chaque attributs 
    et pour chaque paire de produit
    
    Param :
        df : Dataframe à modifier
        category : Catégorie Innoscape (integer)
        seuil_ratio_nan : Seuil de ratio de NaN pour un attribut en-dessous duquel on retire cet attribut du modèle
        list_attributes_standard : Liste attribut de base (prix, couleur, marque, modèle)
        list_units : Liste des attributs quantitatifs
        list_topics : Liste des noms de topics (dépend du nombre de topics)
        
    Return :
        X : array contenant les features de similarité en colonne pour chaque paire de produit
        y : array contenant le label 1 si la paire comparée est identique et label 0 sinon
        pair_id_page : array contenant la paire de modèle de produit
        id_product : array contenant l'id du produit
        list_features : liste des features de similarité retenues
    """
    if mode == 'training':
        # Keep only categories with at least 20 products
        labels_to_keep = df['label'].value_counts()[df['label'].value_counts()>19].index
        df_reduced = df[df['label'].isin(labels_to_keep)]

        if category in labels_to_keep:
            # Keep only product identifiers that is represented by at leats 2 products
            list_products_to_keep = df_reduced['id_page'].value_counts().index.values[df_reduced['id_page'].value_counts()>1]
            df_reduced = df_reduced[df_reduced['id_page'].isin(list_products_to_keep)]

            df_reduced.reset_index(drop=True, inplace=True)

            # Focus on a specific category
            df_category = df_reduced[df_reduced.label == category]

            # Select attributes and fill the missing values
            df_category = select_fill_attributes(df_category, list_units, seuil_ratio_nan)
            list_units_to_keep = df_category.columns[df_category.columns.isin(list_units)].values.tolist()
            list_features =  list_attributes_standard + list_units_to_keep

            # Compute cosine distance & distances (levenshtein, euclidian, boolean) for pairwise products
            cosine_distances = np.array(cosine_pairwise(df_category[list_topics])).reshape(-1, 1)
            distances = distance_pairwise(df_category[list_features])

            # Pair of label
            pair_id_page = np.array(label_pairwise(df_category['id_page'])).reshape(-1,1)

            # Id of product
            id_product = np.array(product_id(df_category['id_product'])).reshape(-1,1)

            # Create variables
            X = np.concatenate((distances, cosine_distances), axis=1)
            y = np.array(create_labels(df_category.id_page.values))

            return X, y, pair_id_page, id_product, list_features

        else:
            print("Il n'y a pas suffisamment de produit dans cette catégorie, veuillez choisir une autre catégorie")

    elif (mode == 'prediction' and nb != None):
        df_category = df[df.label == category]
        # Select attributes and fill the missing values
        df_category = select_fill_attributes(df_category, list_units, seuil_ratio_nan)
        list_units_to_keep = df_category.columns[df_category.columns.isin(list_units)].values.tolist()
        list_features =  list_attributes_standard + list_units_to_keep

        # Compute cosine distance & distances (levenshtein, euclidian, boolean) for pairwise products
        cosine_distances = np.array(cosine_pairwise_2(df_category[list_topics], nb)).reshape(-1, 1)
        distances = distance_pairwise_3(df_category[list_features], nb)

        # Pair of id product
        pair_id_product = np.array(label_pairwise_2(df_category['id_product'], nb)).reshape(-1,1)

        # Create variables
        X = np.concatenate((distances, cosine_distances), axis=1)

        return X, pair_id_product