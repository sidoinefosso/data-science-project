from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.externals import joblib
from scipy.sparse import csr_matrix

def embedding2(df, path_tfidf, path_nmf, mode='save'):
    """
    Fonction qui permet de:
    1) sauvegarder les modèles d'embeddings (mode ='save') -> sauvegarde des modèles TF-IDF et NMF
    2) transformer les données à partir des modèles d'embeddings (mode = 'load') -> les sorties
    correspondantes sont la matrice suite à la tranformation TF-IDF/NMF et la liste du vocabulaire
    """
    # Concaténation des données pertinentes
    for i in range(len(df.columns)):
        if i == 0:
            df.loc[:, "concat"] = df.iloc[:, i]
        else:
            df.loc[:, "concat"] += " " + df.iloc[:, i]
    # Transformation tf-idf 
    if mode == 'save':
        vectorizer = TfidfVectorizer(lowercase=False) 
        tf_idf = csr_matrix(vectorizer.fit_transform(df["concat"]))
        vocab = vectorizer.get_feature_names()
        joblib.dump(vectorizer, path_tfidf) # sauvegarde du modèle
    elif mode == 'load':
        vectorizer = joblib.load(path_tfidf)
        tf_idf = csr_matrix(vectorizer.transform(df["concat"]))
        vocab = vectorizer.get_feature_names()
    else:
        print("Choisir un mode entre 'save' et 'load'.")
        return
    # Transformation NMF
    if mode == 'save':
        nmf = NMF(n_components=250, alpha=.1, l1_ratio=.5).fit(tf_idf)
        joblib.dump(nmf, path_nmf) # sauvegarde du modèle
        return
    elif mode == 'load':
        nmf = joblib.load(path_nmf)
        X = nmf.transform(tf_idf)
        return X, vocab
    else:
        print("Choisir un mode entre 'save' et 'load'.")
        return
  