import numpy as np
import Levenshtein
from sklearn.metrics.pairwise import cosine_similarity
from scipy.special import binom

# Liste des attributs de base et spécifiques
list_attributes_standard = ["product_price", "Couleur", "brand", "model"]
list_units = ["Volt", "Watt", "AmpereHeure", "NewtonMetre", "Poids", "Mesure", "Volume", 'Rpm', 'Joules', 'Metre2']

# Distance booléenne pour les attributs catégoriels
def boolean_distance(attr1, attr2):
    if attr1 == "" or attr2=="":
        return 0.5
    elif attr1 == attr2:
        return 0
    else:
        return 1
    
# Distance euclidienne normalisée
def euclidian_distance_customed(price, price_ref):
    return np.sqrt(((price-price_ref)/(price_ref*price))**2)

# Selection des attributs si attributs suffisamment renseignés (taux de nan < threshold) et fill les nan avec la médiane
# Sinon suppression de l'attribut
def select_fill_attributes(df, list_attributes, seuil_ratio_na):
    for attribute in list_attributes:
        ratio_na = df[df[attribute].isna()].shape[0] / df.shape[0]
        if ratio_na < seuil_ratio_na:
            median = df[attribute].value_counts().describe().loc["50%"]
            df[attribute].fillna(median, inplace=True)
        else:
            df.drop(attribute, axis=1, inplace=True)
    return df

# Matrice distance cosine pour chaque paire de produit
def cosine_pairwise(df):
    list_cosine = []
    for i in range(df.shape[0]-1):
        product_ref = np.array(df.iloc[i,:]).reshape(1,-1)
        list_cosine += cosine_similarity(product_ref, df.iloc[i+1:,:].values)[0].tolist()
    return list_cosine

# Matrice distance pour chaque paire de produit
def distance_pairwise(df):
    distances = np.zeros((int(binom(df.shape[0], 2)), df.shape[1]))
    list_features = df.columns
    for j in range(len(list_features)):
        # Iteration
        k = 0
        for i in range(df.shape[0]-1):
            product_ref = df.iloc[i, j]
            products_to_compare = df.iloc[i+1:, j]
            for product in products_to_compare:
                distances[k, j] = dict_metrics[list_features[j]](product_ref, product)
                k += 1
    return distances

# Liste paire label (id_page) pour déterminer les produits comparés
def label_pairwise(df):
    list_id_page = []
    for i in range(df.shape[0]-1):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        list_id = product_ref + '_' + products_to_compare
        list_id_page += list_id.tolist()
    return list_id_page

# Liste paire id produit pour déterminer les produits comparés
def product_id(df):
    list_id = []
    for i in range(df.shape[0]-1):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        for product in products_to_compare:
            list_id.append(product_ref)
    return list_id

# Liste label : 1 si produits identiques, 0 sinon
def create_labels(labels):
    list_labels = []
    for i in range(len(labels)-1):
        product_ref = labels[i]
        products_to_compare = labels[i+1:]
        for product in products_to_compare:
            if product_ref == product:
                list_labels.append(1)
            else:
                list_labels.append(0)
    return list_labels

# Matrice distance cosine pour chaque paire de produit (mode prediction)
# Paire entre produit à identifier et produit de la base
# nb : nombre de nouveau produit à identifier
def cosine_pairwise_2(df, nb):
    list_cosine = []
    for i in range(nb):
        product_ref = np.array(df.iloc[i,:]).reshape(1,-1)
        list_cosine += cosine_similarity(product_ref, df.iloc[i+1:,:].values)[0].tolist()
    return list_cosine

# Matrice distance pour chaque paire de produit (mode prediction)
# Paire entre produit à identifier et produit de la base
# nb : nombre de nouveau produit à identifier
def distance_pairwise_2(df, nb):
    distances = np.zeros((int(df.shape[0]*nb - ((nb*(nb+1))/2)), df.shape[1]))
    list_features = df.columns
    for j in range(len(list_features)):
        # Iteration
        k = 0
        for i in range(nb):
            product_ref = df.iloc[i, j]
            products_to_compare = df.iloc[i+1:, j]
            for product in products_to_compare:
                distances[k, j] = dict_metrics[list_features[j]](product_ref, product)
                k += 1
    return distances

# Liste paire label (id_page) pour déterminer les produits comparés (mode prediction)
def label_pairwise_2(df, nb):
    list_id_page = []
    list_ref = [] 
    for i in range(nb):
        product_ref = df.iloc[i]
        products_to_compare = df.iloc[i+1:]
        list_id = product_ref + '_' + products_to_compare
        list_id_page += list_id.tolist()
    return list_id_page


# Dictionnary of metrics used to compare each attribute 
dict_metrics = {"product_price": euclidian_distance_customed, "Couleur": boolean_distance, 
                "brand": boolean_distance, "model": Levenshtein.distance, 
                "Volt": euclidian_distance_customed, "Watt": euclidian_distance_customed,
                "AmpereHeure": euclidian_distance_customed, "NewtonMetre": euclidian_distance_customed,
                "Poids": euclidian_distance_customed, "Mesure": euclidian_distance_customed,
                "Volume": euclidian_distance_customed, "Rpm": euclidian_distance_customed, 
                "Joules": euclidian_distance_customed, "Metre2": euclidian_distance_customed}


def get_matrix_similarity(df, category, seuil_ratio_nan, list_topics, mode, nb=None, list_attributes_standard=list_attributes_standard, list_units=list_units):
   
    """
    Fonction pour créer la matrice contenant les features de similarité par rapport à chaque attributs 
    et pour chaque paire de produit
    
    Param :
        df : Dataframe à modifier
        category : Catégorie Innoscape (integer)
        seuil_ratio_nan : Seuil de ratio de NaN pour un attribut en-dessous duquel on retire cet attribut du modèle
        mode : Si mode training ou prediction
        nb : Nombre de nouveau produit à identifier (seulement mode prediction)
        list_attributes_standard : Liste attribut de base (prix, couleur, marque, modèle)
        list_units : Liste des attributs quantitatifs
        list_topics : Liste des noms de topics (dépend du nombre de topics)
        
    Return :
        X : array contenant les features de similarité en colonne pour chaque paire de produit
        y : array contenant le label 1 si la paire comparée est identique et label 0 sinon
        pair_id_page : array contenant la paire de modèle de produit
        pair_id_product : array contenant la paire d'id du produit
    """
    if mode == 'training':
        # On garde les catégories contenant au moins 20 produits
        labels_to_keep = df['label'].value_counts()[df['label'].value_counts()>19].index
        df_reduced = df[df['label'].isin(labels_to_keep)]

        if category in labels_to_keep:
            # On garde les produits ayant au moins une paire
            list_products_to_keep = df_reduced['id_page'].value_counts().index.values[df_reduced['id_page'].value_counts()>1]
            df_reduced = df_reduced[df_reduced['id_page'].isin(list_products_to_keep)]

            df_reduced.reset_index(drop=True, inplace=True)

            # Focus sur une catégorie
            df_category = df_reduced[df_reduced.label == category]

            # Selection des attributs et fill nan
            df_category = select_fill_attributes(df_category, list_units, seuil_ratio_nan)
            list_units_to_keep = df_category.columns[df_category.columns.isin(list_units)].values.tolist()
            list_features =  list_attributes_standard + list_units_to_keep

            # Calcul distance cosine & distances (levenshtein, euclidian, boolean) pour chaque paire de produit
            cosine_distances = np.array(cosine_pairwise(df_category[list_topics])).reshape(-1, 1)
            distances = distance_pairwise(df_category[list_features])

            # Paire id_page
            pair_id_page = np.array(label_pairwise(df_category['id_page'])).reshape(-1,1)

            # Paire id product
            pair_id_product = np.array(product_id(df_category['id_product'])).reshape(-1,1)

            # Variables
            X = np.concatenate((distances, cosine_distances), axis=1)
            y = np.array(create_labels(df_category.id_page.values))

            return X, y, pair_id_page, pair_id_product

        else:
            print("Il n'y a pas suffisamment de produit dans cette catégorie, veuillez choisir une autre catégorie")

    elif (mode == 'prediction' and nb != None):
        df_category = df[df.label == category]
        # Selection des attributs et fill nan
        df_category = select_fill_attributes(df_category, list_units, seuil_ratio_nan)
        list_units_to_keep = df_category.columns[df_category.columns.isin(list_units)].values.tolist()
        list_features =  list_attributes_standard + list_units_to_keep

        # Calcul distance cosine & distances (levenshtein, euclidian, boolean) pour chaque paire de produit
        cosine_distances = np.array(cosine_pairwise_2(df_category[list_topics], nb)).reshape(-1, 1)
        distances = distance_pairwise_2(df_category[list_features], nb)
        
        # Paire id product
        pair_id_product = np.array(label_pairwise_2(df_category['id_product'], nb)).reshape(-1,1)

        # Variables
        X = np.concatenate((distances, cosine_distances), axis=1)

        return X, pair_id_product