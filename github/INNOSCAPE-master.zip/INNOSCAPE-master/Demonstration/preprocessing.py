# Librairies
import treetaggerwrapper

# Caractères spéciaux
dico1 = {",":" ", "'":" ", ";":" ", ":":" ", "\?":" ", "!":" ", "\.":'', "  ":" ", "  ":" ",
         "\(":"","\)":"","\[":"","\]":"","-":" ","\+":"","/":"","\*":"","–":" ",
         "&":"et"}

# Caractères avec accents
dico2 = {'à':'a','â':'a','ä':'a',
              'é':'e','è':'e','ê':'e','ë':'e',
              'ï':'i','î':'i',
              'ô':'o','ö':'o',
              'ù':'u','û':'u',
              'ç':'c'}


# Charge un fichier txt en un set  
# Param : path_txt - Chemin fichier txt
# Return : Set
def load_txt(path_txt):
    file =  set(open(path_txt).read().split())
    return file


# Union de deux fichiers txt en un set
# Param : Deux fichiers txt 
# Return : Set 
def union_set(path_txt1, path_txt2):
    txt1 = load_txt(path_txt1)
    txt2 = load_txt(path_txt2)
    return txt1.union(txt2)


# Processer les données : retrait des chiffres et caractères spéciaux, lettres en minuscules et lemmatisation
# Param : df - Dataframe à modifier, 
#         list_col - Liste des colonnes à modifier, 
#         list_new_col - Liste des nouvelles colonnes, 
#         dico1 - Dictionnaire pour les caractères spéciaux, 
#         dico2 - Dictionnaire pour les caractères avec accents, 
#         tag_dir - Chemin du dossier contenant treetagger 
# Return : Dataframe dont les champs sont des strings
def f_treetagger(df, list_col, list_new_col, dico1, dico2, tag_dir):

    # Def treetagger
    class TreeTaggerWord:
        def __init__(self, triplet):
            self.word,self.postag,self.lemma = triplet
        
    def formatTTG(output):
        words = []
        for w in output:
            words.append(TreeTaggerWord(w.split("\t")))
        return words
    
    tagger = treetaggerwrapper.TreeTagger(TAGLANG='fr',TAGDIR=tag_dir,
    TAGINENC='utf-8',TAGOUTENC='utf-8')

    regex = r"\d"
    replace = ""

    # Processing
    for col, new_col in zip(list_col, list_new_col):
        df[col].replace(dico1, regex=True, inplace=True)
        df[new_col] = df[col].str.replace(regex, replace)  # Retrait des chiffres
        df[new_col] = df[new_col].str.lower()
        df[new_col] = df[new_col].apply(lambda x: ' '.join([word.lemma for word in formatTTG(tagger.TagText(x))])) 
        df[new_col].replace(dico2, regex=True, inplace=True)
    return df


# Fonction intermédiaire pour retirer les stop words
def clean_stop_words(row, column_name, stop_words):
    return list(set(row[column_name]) - stop_words)


# Cleaner les données : retirer les stop words et mots inférieurs à 2 caractères
# Param : df - Dataframe à modifier, 
#         list_col - Liste des colonnes à modifier, 
#         list_new_col - Liste des nouvelles colonnes, 
#         stop_words - Set de stop words + marques
# Return : Dataframe dont les champs sont des strings
def f_clean_stop_words(df, list_col, list_col_new, stop_words):

    for col, new_col in zip(list_col, list_col_new):
        df[new_col] = df[col].str.split()
        df[new_col] = df.apply(clean_stop_words, args=([new_col, stop_words]), axis=1)
        df[new_col] = df[new_col].apply(lambda x: [word for word in x if len(word)>2])
        df[new_col] = df[new_col].apply(lambda x: ' '.join(x))
    return df


# Preprocessing
# Param : df - Dataframe à modifier, 
#         list_col - Liste des colonnes à modifier, 
#         dico1 - Dictionnaire pour les caractères spéciaux, 
#         dico2 - Dictionnaire pour les caractères avec accents, 
#         stop_words - Set de stop words + marques, 
#         tag_dir - Chemin du dossier contenant treetagger
# Return : Dataframe cleané
def preprocessing(df, list_col, stop_words, tag_dir, dico1=dico1, dico2=dico2):
    
    # Processing treetagger
    list_col_treetagger = [col+"_treetagger" for col in list_col]
    df = f_treetagger(df, list_col, list_col_treetagger, dico1, dico2, tag_dir)
    
    # Processing de cleaning stop words
    list_col_clean = [col+"_clean" for col in list_col]
    df = f_clean_stop_words(df, list_col_treetagger, list_col_clean, stop_words)
    
    # Garder les colonnes clean
    df = df[list_col_clean]
    
    return df
