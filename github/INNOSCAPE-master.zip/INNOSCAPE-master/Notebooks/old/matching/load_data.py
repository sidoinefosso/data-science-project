import pandas as pd

def load_data(path_to_file, columns_to_keep=None):
    """
    Importation des données vendeurs à partir des colonnes sélectionnées et cleaning des données
    """    
    
    if columns_to_keep == None:
        df = pd.read_csv(path_to_file)
    else:
        df = pd.read_csv(path_to_file, usecols=columns_to_keep, sep = ",")
    
    # On remplace les NA par valeur vide
    df.brand_seller.fillna("", inplace=True)
    
    # On retire les produits sans prix
    df.drop(df[df.product_price.isna()].index, inplace=True)
    df.reset_index(inplace=True, drop=True)
    
    df.rename(columns={'product_name': 'productseller_name'}, inplace=True)
    
    return df