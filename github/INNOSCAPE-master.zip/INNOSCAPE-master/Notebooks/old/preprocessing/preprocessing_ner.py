import re
import pandas as pd
import numpy as np

list_attributes = ['Volume', 'Mesure', 'Poids', 'AmpereHeure', 'NewtonMetre', 'Watt', 'Volt', 'Rpm', 'Joules', 'Metre2']

# Récupérer les attributs : Poids, Mesure, Volume, Couleur etc
def ner_attributs(df, name_col):
    df['Poids'] = df[name_col].apply(lambda x: re.search(r"([\d.,]+)\s*(g|grammes|kg)\b", x).group() if re.search(r"([\d.,]+)\s*(g|grammes|kg)\b", x) is not None else '')
    df['Mesure'] = df[name_col].apply(lambda x: re.search(r"([\d.,]+)\s*(mm|cm|m|mètres|mètre)\b", x).group() if re.search(r"([\d.,]+)\s*(mm|cm|m|mètres|mètre)\b", x) is not None else '')
    df['Volume'] = df[name_col].apply(lambda x: re.search(r"([\d.,]+)\s*(ml|cl|l|litres|litre|cm³)\b", x).group() if re.search(r"([\d.,]+)\s*(ml|cl|l|litres|litre|cm³)\b", x) is not None else '')
    df['Volt'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(v|volts|volt)\b", r"\1", re.search(r"([\d.,]+)\s*(v|volts|volt)\b", x).group()) if re.search(r"([\d.,]+)\s*(v|volts|volt)\b", x) is not None else '')
    df['Watt'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(w|watts|watt)\b", r"\1", re.search(r"([\d.,]+)\s*(w|watts|watt)\b", x).group()) if re.search(r"([\d.,]+)\s*(w|watts|watt)\b", x) is not None else '')
    df['AmpereHeure'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(ah)\b", r"\1", re.search(r"([\d.,]+)\s*(ah)\b", x).group()) if re.search(r"([\d.,]+)\s*(ah)\b", x) is not None else '')
    df['NewtonMetre'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(nm)\b", r"\1", re.search(r"([\d.,]+)\s*(nm)\b", x).group()) if re.search(r"([\d.,]+)\s*(nm)\b", x) is not None else '')
    df['Rpm'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(nm)\b", r"\1", re.search(r"([\d.,]+)\s*(nm)\b", x).group()) if re.search(r"([\d.,]+)\s*(nm)\b", x) is not None else '')
    df['Joules'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(j|joules)\b", r"\1", re.search(r"([\d.,]+)\s*(j|joules|joule)\b", x).group()) if re.search(r"([\d.,]+)\s*(j|joules|joule)\b", x) is not None else '')
    df['Metre2'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(m²)\b", r"\1", re.search(r"([\d.,]+)\s*(m²)\b", x).group()) if re.search(r"([\d.,]+)\s*(m²)\b", x) is not None else '')
    df['Batterie'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(batteries|batterie)\b", r"\1", re.search(r"([\d.,]+)\s*(batteries|batterie)\b", x).group()) if re.search(r"([\d.,]+)\s*(batteries|batterie)\b", x) is not None else '')
    df['Couleur'] = df[name_col].apply(lambda x: re.search(r"\b(gris|noir|marron|beige|rouge|blanc|bleu|vert|argent|jaune|orange|multicolore)\b", x).group() if re.search(r"\b(gris|noir|marron|beige|rouge|blanc|bleu|vert|argent|jaune|orange|multicolore)\b", x) is not None else '')
    return df


# Normaliser unité de mesure et processing des attributs
# Exemple : poids en gramme, mesure en mètre, volume en litre etc
def normalization_unit(df, name_col):
    # Normalisation
    dico = {'Poids':{'g':1, 'kg':1000}, 'Mesure':{'mm':0.001, 'm':1, 'cm':0.01}, 'Volume':{'ml':0.001, 'cl':0.01, 'l':1, 'cm³':0.001}}
    dico_regex = {'Poids':'(g|kg)', 'Mesure':'(mm|cm|m)', 'Volume':'(ml|cl|l|cm³)'}
    if name_col in dico:
        df[name_col] = df[name_col].apply(lambda x: float(re.search('\d+', x).group())*dico[name_col][re.search(dico_regex[name_col], x).group()] if re.search("\d+", x) and re.search(dico_regex[name_col], x) is not None else '')
    # Preprocessing
    df[name_col] = df[name_col].apply(lambda x: np.NaN if x == "" else x)
    df[name_col] = df[name_col].apply(lambda x: float(x.replace(',','.')) if isinstance(x, str) else x)
    df[name_col] = df[name_col].apply(lambda x: x if x != 0 else np.NaN)
    return df


# Récupérer la marque
def ner_brand(df, name_col, brand_col=None):
    # Liste des marques
    unique_brand = open('../../Data/brand.txt').read().split(',')
    unique_brand = [x for x in unique_brand]
    regex = r'\b(' + r'|'.join(unique_brand) + r')\b'
    regex2 = r'(' + r'|'.join(unique_brand) + r')'
    # Marque pour chaque produit
    df['brand'] = df[name_col].apply(lambda x: re.search(regex, x).group() if re.search(regex, x) is not None else '')
    # Gestion sans marque suite à la première regex
    index_no_brand = df[df.brand == ''].index.tolist()
    for index in index_no_brand:
        if brand_col is not None:
            if re.search(regex2, df[brand_col].iloc[index]) is not None:
                df['brand'].iloc[index] = re.search(regex2, df[brand_col].iloc[index]).group() 
        elif re.search(regex2, df[name_col].iloc[index]) is not None:
            df['brand'].iloc[index] = re.search(regex2, df[name_col].iloc[index]).group() 
        else:
            df['brand'].iloc[index] = ''
    # Cas spécial : black and decker
    df['brand'] = df['brand'].apply(lambda x: 'blackanddecker' if x in ['black & decker','black and decker', 'black + decker'] else x)
    return df


# Retirer les unités de mesure et marque de la description
def preprocessing_description(df, name_col):
    # Retirer les mesures
    df['Description'] = df[name_col].apply(lambda x: re.sub(r"([\d.,]+)\s*(g|gramme|grammes|kg|mm|cm|m|mètre|mètres|ml|cl|l|litre|litres|v|volt|volts|w|watt|watts|ah|nm|rpm|j|joule|joules|cm³|m²)\b", "", x))
    df['Description'] = df['Description'].apply(lambda x: re.sub(r"(gris|noir|marron|beige|rouge|blanc|bleu|vert|argent|jaune|orange|multicolore)\b", "", x))
    # Retirer les marques
    unique_brand = open('../../Data/brand.txt').read().split(',')
    unique_brand = [x for x in unique_brand]
    regex = r'(' + r'|'.join(unique_brand) + r')'
    df['Description'] = df['Description'].apply(lambda x: re.sub(regex, "", x))
    return df


# Récupérer le modèle et retire le modèle de la description
def ner_model_preprocessing(df):
    # mise en place regex
    regex = r'[a-z0-9]+[-]?[0-9]+[a-z0-9]+(?= )'
    # Marque pour chaque produit
    df['model'] = df['Description'].apply(lambda x: re.search(regex, x).group() if re.search(regex, x) is not None else '')
    # Clean description : retirer les modèles
    df['Description'] = df['Description'].apply(lambda x: re.sub(r"[a-z0-9]+[-]?[0-9]+[a-z0-9]+(?= )", "", x))
    return df


def ner_preprocessing(df, col_description, col_brand=None):
    # Lowercase
    df[col_description] = df[col_description].str.lower()
    if col_brand is not None:
        df[col_brand] = df[col_brand].str.lower()
    df = ner_attributs(df, col_description)
    df = preprocessing_description(df, col_description)
    for attribute in list_attributes:
        df = normalization_unit(df, attribute)
    df = ner_brand(df, col_description, col_brand)
    df = ner_model_preprocessing(df)
    return df
