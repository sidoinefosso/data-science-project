# Librairies
from nltk.stem.snowball import FrenchStemmer
from sklearn.feature_extraction.text import CountVectorizer


def f_regex(df, list_col, dico):
    """ Reformattage des données en supprimant les chiffres et en remplaçant les mots à partir du dictionnaire
    dans le dataframe
    """
    regex = r"\d"
    replace = ""
    for col in list_col:
        df[col+"_formatted"] = df[col].str.replace(regex, replace)
        df[col+"_formatted"] = df[col+"_formatted"].str.lower()
        df[col+"_formatted"].replace(dico, regex=True, inplace=True)
    return df


def clean_stop_words(row, column_name, stop_words):
    """ Retirer les mots de la liste stop_words
    """
    return list(set(row[column_name]) - stop_words)


def f_clean_stop_words(df, list_col, list_col_new, stop_words):
    """ Retirer les stop_words et les mots inférieurs à 3 mots strict dans le dataframe
    """
    for col, new_col in zip(list_col, list_col_new):
        df[new_col] = df[col].str.split()
        df[new_col] = df.apply(clean_stop_words, args=([new_col, stop_words]), axis=1)
        df[new_col] = df[new_col].apply(lambda x: [word for word in x if len(word)>2])
    return df


# def f_stemming(df, list_col, list_new_col):
#     """ Récupérer que la racine de tous les mots et renvoyer un set des mots racines
#     """
#     stemmer = FrenchStemmer()
#     for col, new_col in zip(list_col, list_new_col):
#         liste_fam = list(df[col])
#         col_stemmed = []
#         for liste in liste_fam:
#             s = [stemmer.stem(word) for word in liste]
#             col_stemmed.append(' '.join(set(s)))
#         df[new_col] = col_stemmed
#     return df


def preprocessing(df, list_col, dico, stop_words):
    # Préparation des noms de colonnes
    list_col_formatted = [col+"_formatted" for col in list_col]
    list_col_clean = [col+"_clean" for col in list_col]
#     list_col_stem = [col+"_stem" for col in list_col]
    # Transformation des colonnes
    df = f_regex(df, list_col, dico)
    df = f_clean_stop_words(df, list_col_formatted, list_col_clean, stop_words)
#     df = f_stemming(df, list_col_clean, list_col_stem)
    return df


def f_bagwords(df_seller, list_col_seller, list_new_col_seller, df_ref, list_col_ref, list_new_col_ref):
    """ Création du vocabulaire et transformation des mots en vecteurs [index, nb_occurences] 
    """
    # Création vocabulaire
    list_words = []
    list_vocabulary = []
    dict_vocabulary = {}
    i = 0
    # Récupération de tous les groupes de mots uniques
    for col in list_col_seller:
        list_words += list(df_seller[col])
    list_words = list(set(list_words))
    for col in list_col_ref:
        list_words += list(df_ref[col])
    list_words = list(set(list_words))
    # Récupération de tous les mots uniques
    for words in list_words:
        list_vocabulary += words.split(" ")
    list_vocabulary = list(set(list_vocabulary))
    # Création du dictionnaire de vocabulaire
    dict_vocabulary = {word: index for (index, word) in enumerate(list_vocabulary)}
    # Transformation Word2Vec avec la librairie Sklearn
    for col, new_col in zip(list_col_seller, list_new_col_seller):
        vectorizer = CountVectorizer(vocabulary=dict_vocabulary)
        df_seller[new_col] = vectorizer.fit_transform(df_seller[col]).toarray().tolist()
    for col, new_col in zip(list_col_ref, list_new_col_ref):
        vectorizer = CountVectorizer(vocabulary=dict_vocabulary)
        df_ref[new_col] = vectorizer.fit_transform(df_ref[col]).toarray().tolist()
    return df_seller, df_ref