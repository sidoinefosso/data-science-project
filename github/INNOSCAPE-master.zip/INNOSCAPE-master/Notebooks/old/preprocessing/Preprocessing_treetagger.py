# Librairies
from nltk.stem.snowball import FrenchStemmer
import treetaggerwrapper


def f_regex(df, list_col, dico):
    """ Reformattage des données en supprimant les chiffres et en remplaçant les mots à partir du dictionnaire
    dans le dataframe
    """
    regex = r"\d"
    replace = ""
    for col in list_col:
        df[col+"_formatted"] = df[col].str.replace(regex, replace)
        df[col+"_formatted"] = df[col+"_formatted"].str.lower()
        df[col+"_formatted"].replace(dico, regex=True, inplace=True)
    return df


def clean_stop_words(row, column_name, stop_words):
    """ Retirer les mots de la liste stop_words
    """
    return list(set(row[column_name]) - stop_words)


def f_clean_stop_words(df, list_col, list_col_new, stop_words):
    """ Retirer les stop_words et les mots inférieurs à 3 mots strict dans le dataframe
    """
    for col, new_col in zip(list_col, list_col_new):
        df[new_col] = df[col].str.split()
        df[new_col] = df.apply(clean_stop_words, args=([new_col, stop_words]), axis=1)
        df[new_col] = df[new_col].apply(lambda x: [word for word in x if len(word)>2])
    return df


def f_stemming(df, list_col, list_new_col):
    """ Récupérer que la racine de tous les mots et renvoyer un set des mots racines
    """
    stemmer = FrenchStemmer()
    for col, new_col in zip(list_col, list_new_col):
        liste_fam = list(df[col])
        col_stemmed = []
        for liste in liste_fam:
            s = [stemmer.stem(word) for word in liste]
            col_stemmed.append(s)
        df[new_col] = col_stemmed
    return df


def f_treetagger(df, list_col, list_new_col, dico, tag_dir):
    """ Récupérer que la racine de tous les mots et renvoyer un set des mots racines avec spacy
    """
    class TreeTaggerWord:
        def __init__(self, triplet):
            self.word,self.postag,self.lemma = triplet
        
    def formatTTG(output):
        words = []
        for w in output:
            words.append(TreeTaggerWord(w.split("\t")))
        return words
    
    tagger = treetaggerwrapper.TreeTagger(TAGLANG='fr',TAGDIR=tag_dir,
    TAGINENC='utf-8',TAGOUTENC='utf-8')

    regex = r"\d"
    replace = ""

    for col, new_col in zip(list_col, list_new_col):
        df[new_col] = df[col].str.replace(regex, replace)
        df[new_col] = df[new_col].str.lower()
        df[new_col] = df[new_col].apply(lambda x: ' '.join([word.lemma for word in formatTTG(tagger.TagText(x))])) 
        df[new_col].replace(dico, regex=True, inplace=True)
    return df


def preprocessing(df, list_col, dico, stop_words, tag_dir):
    list_col_treetagger = [col+"_treetagger" for col in list_col]
    df = f_treetagger(df, list_col, list_col_treetagger, dico, tag_dir)
    list_col_clean = [col+"_clean" for col in list_col]
    df = f_clean_stop_words(df, list_col_treetagger, list_col_clean, stop_words)
    return df


