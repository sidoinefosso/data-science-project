# Librairies
import treetaggerwrapper
import numpy as np
import re

from Preprocessing import *

# Dictionnaire de regex pour chaque attribut (modifiable)
dico_regex = {'Poids':r"(\b[\d.,]+)\s*(g|grammes|kg)\b", 
              'Mesure':r"(\b[\d.,]+)\s*(mm|cm|m|mètres|mètre)\b",
              'Volume':r"(\b[\d.,]+)\s*(ml|cl|l|litres|litre|cm³)\b",
              'Volt':r"(\b[\d.,]+)\s*(v|volts|volt)\b",
              'Watt':r"(\b[\d.,]+)\s*(w|watts|watt)\b",
              'AmpereHeure':r"(\b[\d.,]+)\s*(ah)\b",
              'NewtonMetre':r"(\b[\d.,]+)\s*(nm)\b",
              'Rpm':r"(\b[\d.,]+)\s*(rpm)\b",
              'Joules':r"(\b[\d.,]+)\s*(j|joules)\b",
              'Metre2':r"(\b[\d.,]+)\s*(m²)\b",
              'Batterie':r"(\b[\d.,]+)\s*(batteries|batterie)\b",
              'Couleur':r"\b(gris|noir|marron|beige|rouge|blanc|bleu|vert|argent|jaune|rose|violet|orange|multicolore)\b",
              'Modele':r"[a-z0-9]+[-]?[0-9]+[a-z0-9]+(?= )",
              'All':r"(\b[\d.,]+)\s*(g|gramme|grammes|kg|mm|cm|m|mètre|mètres|ml|cl|l|litre|litres|v|volt|volts|w|watt|watts|ah|nm|rpm|j|joule|joules|cm³|m²)\b"}


def preprocessing_attributs(df, name_col, dico_regex):
    """
    Preprocessing pour récupérer les attributs : Poids, Mesure, Volume, Couleur...
    
    Param : 
        df : Dataframe à modifier
        name_col : Colonne où extraire les attributs
        dico_regex : Dictionnaire contenant les regex pour extraire chaque attribut
        
    Return : Dataframe avec les attributs
    """
    
    df['Poids'] = df[name_col].apply(lambda x: re.search(dico_regex['Poids'], x).group() 
                                     if re.search(dico_regex['Poids'], x) is not None else '')
    df['Mesure'] = df[name_col].apply(lambda x: re.search(dico_regex['Mesure'], x).group() 
                                      if re.search(dico_regex['Mesure'], x) is not None else '')
    df['Volume'] = df[name_col].apply(lambda x: re.search(dico_regex['Volume'], x).group() 
                                      if re.search(dico_regex['Volume'], x) is not None else '')
    df['Volt'] = df[name_col].apply(lambda x: re.sub(dico_regex['Volt'], r"\1", re.search(dico_regex['Volt'], x).group()) 
                                    if re.search(dico_regex['Volt'], x) is not None else '')
    df['Watt'] = df[name_col].apply(lambda x: re.sub(dico_regex['Watt'], r"\1", re.search(dico_regex['Watt'], x).group()) 
                                    if re.search(dico_regex['Watt'], x) is not None else '')
    df['AmpereHeure'] = df[name_col].apply(lambda x: re.sub(dico_regex['AmpereHeure'], r"\1", re.search(dico_regex['AmpereHeure'], x).group()) 
                                           if re.search(dico_regex['AmpereHeure'], x) is not None else '')
    df['NewtonMetre'] = df[name_col].apply(lambda x: re.sub(dico_regex['NewtonMetre'], r"\1", re.search(dico_regex['NewtonMetre'], x).group()) 
                                           if re.search(dico_regex['NewtonMetre'], x) is not None else '')
    df['Rpm'] = df[name_col].apply(lambda x: re.sub(dico_regex['Rpm'], r"\1", re.search(dico_regex['Rpm'], x).group()) 
                                   if re.search(dico_regex['Rpm'], x) is not None else '')
    df['Joules'] = df[name_col].apply(lambda x: re.sub(dico_regex['Joules'], r"\1", re.search(dico_regex['Joules'], x).group())
                                      if re.search(dico_regex['Joules'], x) is not None else '')
    df['Metre2'] = df[name_col].apply(lambda x: re.sub(dico_regex['Metre2'], r"\1", re.search(dico_regex['Metre2'], x).group())
                                      if re.search(dico_regex['Metre2'], x) is not None else '')
    df['Batterie'] = df[name_col].apply(lambda x: re.sub(dico_regex['Batterie'], r"\1", re.search(dico_regex['Batterie'], x).group()) if re.search(dico_regex['Batterie'], x) is not None else '')
    df['Couleur'] = df[name_col].apply(lambda x: re.search(dico_regex['Couleur'], x).group() 
                                       if re.search(dico_regex['Couleur'], x) is not None else '')
    return df


def preprocessing_description(df, name_col, new_col, dico_regex, unique_brand):
    """
    Preprocessing pour retirer les attributs (unités de mesure, caractéristiques) et marque de la description
    
    Param :
        df : Dataframe à modifier
        name_col : Colonne description
        new_col : Nouvelle colonne description sans les valeurs attributs et marque
        dico_regex : Dictionnaire contenant les regex pour extraire chaque attribut
        unique_brand : Liste des marques 
        
    Return : Dataframe
    """
    
    df[new_col] = df[name_col].apply(lambda x: re.sub(dico_regex['All'], "", x))
    df[new_col] = df[new_col].apply(lambda x: re.sub(dico_regex['Couleur'], "", x))
    
    # Liste des marques
    regex = r'(' + r'|'.join(unique_brand) + r')'
    df[new_col] = df[new_col].apply(lambda x: re.sub(regex, "", x))
    
    return df


def normalization_unit(df, name_col):
    """
    Normaliser les unités de mesure
    Exemple : Poids en gramme, Mesure en mètre, Volume en litre etc
    
    Param :
        df : Dataframe à modifier
        name_col : Colonne attribut
        
    Return : Dataframe
    """
    
    dico = {'Poids':{'g':1, 'gramme':1, 'grammes':1, 'kg':1000}, 'Mesure':{'mm':0.001, 'm':1, 'mètre':1, 'mètres':1, 'cm':0.01}, 'Volume':{'ml':0.001, 'cl':0.01, 'l':1, 'litre':1, 'litres':1, 'cm³':0.001}}
    dico_regex = {'Poids':'(g|gramme|grammes|kg)', 'Mesure':'(mm|cm|m|mètre|mètres)', 'Volume':'(ml|cl|l|litre|litres|cm³)'}
    
    df[name_col + '_unit'] = df[name_col].apply(lambda x: float(re.search('\d+', x).group())*dico[name_col][re.search(dico_regex[name_col], x).group()] if re.search("\d+", x) and re.search(dico_regex[name_col], x) is not None else '')
    
    return df


def brand(df, raw_brand, raw_description, new_brand, unique_brand):
    """
    Ajouter les marques (uniformiser, remplir les marques manquantes)
    
    Param :
        df : Dataframe à modifier
        raw_brand : Colonne marque
        raw_description : Colonne description
        new_brand : Nouvelle colonne marque
        unique_brand : Liste des marques
        
    Return : Dataframe
    """
        
    regex = r'\b(' + r'|'.join(unique_brand) + r')\b'
    regex2 = r'(' + r'|'.join(unique_brand) + r')'
    
    # Marque pour chaque produit
    df[new_brand] = df[raw_description].apply(lambda x: re.search(regex, x).group() if re.search(regex, x) is not None else '')
    
    # Gestion sans marque suite à la première regex
    index_no_brand = df[df.brand == ''].index.tolist()
    for index in index_no_brand:
        if re.search(regex2, df[raw_brand].iloc[index]) is not None:
            df[new_brand].iloc[index] = re.search(regex2, df[raw_brand].iloc[index]).group() 
        elif re.search(regex2, df[raw_description].iloc[index]) is not None:
            df[new_brand].iloc[index] = re.search(regex2, df[raw_description].iloc[index]).group() 
        else:
            df[new_brand].iloc[index] = ''
        
    return df


# Ajouter les modèles
def fmodel(df, model, new_description, dico_regex):
    """
    Extraire l'attribut modèle
    
    Param :
        df : Dataframe à modifier
        model : Colonne modele
        new_description : Nouvelle colonne description
        dico_regex : Dictionnaire contenant les regex pour extraire chaque attribut
        
    Return : Dataframe
    """
    
    df[model] = df[new_description].apply(lambda x: re.search(dico_regex['Modele'], x).group() if re.search(dico_regex['Modele'], x) is not None else '')
    return df


def fill_nan(df, name_col):
    """
    Remplir les valeures nulles par des NaN
    
    Param :
        df : Dataframe à modifier
        name_col : Colonne
        
    Return : Dataframe
    """
    df[name_col] = df[name_col].apply(lambda x: x if x!= 0 else np.NaN)
    return df


def lowercase(df, name_col):
    """
    Lettre en minuscule
    
    Param :
        df : Dataframe à modifier
        name_col : Colonne
        
    Return : Dataframe
    """
    
    df[name_col] = df[name_col].str.lower()
    return df


def preprocessing_similarity(df, raw_description, raw_brand, new_description, new_brand, model, unique_brand, stop_words, tag_dir, dico1, dico2, dico_regex=dico_regex):
    """
    Fonction de preprocessing globale
    Extraction des attributs, normalisation des unités de mesure, gestion des marques, 
    cleaning et lemmatisation description, traitement spécifiques
    
    Param :
        df : Dataframe à modifier
        raw_description : Colonne description
        raw_brand : Colonne marque
        new_description : Nouvelle colonne marque
        new_brand : Nouvelle colonne marque
        model : Colonne modèle
        unique_brand : Liste des marques
        stop_words : Stop words
        
    Return : Dataframe
    """
    
    list_attribute = ['Volume_unit', 'Poids_unit', 'Mesure_unit', 'Joules', 'Rpm', 'Metre2', 'AmpereHeure', 'Watt', 'Volt', 'NewtonMetre']
    
    # Lettre en minuscule
    df = lowercase(df, raw_description)
    df = lowercase(df, raw_brand)
    
    # Extraction attributs
    df = preprocessing_attributs(df, raw_description, dico_regex)
    
    # Retirer les attributs de la description
    df = preprocessing_description(df, raw_description, new_description, dico_regex, unique_brand)
    
    # Normalisation des unités de mesure
    df = normalization_unit(df, 'Poids')
    df = normalization_unit(df, 'Mesure')
    df = normalization_unit(df, 'Volume')
    
    # Gestion des marques
    df = brand(df, raw_brand, raw_description, new_brand, unique_brand)
    
    # Extraction de l'attribut modèle
    df = fmodel(df, model, new_description, dico_regex)
    
    # Cas spécial : black and decker
    df[new_brand] = df[new_brand].apply(lambda x: 'blackanddecker' if x in ['black & decker','black and decker', 'black + decker'] else x)

    # Clean description : retirer les modèles
    df[new_description] = df[new_description].apply(lambda x: re.sub(dico_regex['Modele'], "", x))
    
    # Conversion des données en float et NaN pour les champs vide par défaut, possible de paramétrer
    df['Volume_unit'] = df['Volume_unit'].apply(lambda x: float(x) if x != '' else np.NaN)
    df['Poids_unit'] = df['Poids_unit'].apply(lambda x: float(x) if x != '' else np.NaN)
    df['Mesure_unit'] = df['Mesure_unit'].apply(lambda x: float(x) if x != '' else np.NaN)
    df['Metre2'] = df['Metre2'].apply(lambda x: float(x) if x != '' else np.NaN)
    df['Rpm'] = df['Rpm'].apply(lambda x: float(x) if x != '' else np.NaN)
    df['Joules'] = df['Joules'].apply(lambda x: float(x.replace(',','.')) if x != '' else np.NaN)
    df['AmpereHeure'] = df['AmpereHeure'].apply(lambda x: float(x.replace(',','.')) if x != '' else np.NaN)
    df['Watt'] = df['Watt'].apply(lambda x: float(x.replace(',','.')) if x != '' else np.NaN)
    df['Volt'] = df['Volt'].apply(lambda x: float(x.replace(',','.')) if x != '' else np.NaN)
    df['NewtonMetre'] = df['NewtonMetre'].apply(lambda x: float(x.replace(',','.')) if x != '' else np.NaN)
    
    # Remplir les colonnes par des NaN si valeurs nulles
    for attribute in list_attribute:
        df = fill_nan(df, attribute)
     
    # Lemmatisation et traitement description
    preprocessing(df, [new_description], dico1, dico2, stop_words, tag_dir)
    
    return df
    
    


