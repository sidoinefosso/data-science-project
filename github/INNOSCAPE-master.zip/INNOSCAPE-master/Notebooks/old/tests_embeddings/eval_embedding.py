# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 00:21:22 2019

@author: JN
"""
###############################################################################
### Module pour la comparaison d'embeddings
###############################################################################

import pandas as pd
import numpy as np
from scipy import stats as scs
import gensim.models as models
from gensim import corpora
from gensim import matutils

def embedding(df_test, col_name, dictionary, gensim_model):
    """ transcrit une colonne texte d'un dataframe dans un embedding défini au préalable
    Inputs:
        -df_test : dataframe contenant le texte à transformer
        -col_name : nom de la colonne à traiter (string)
        -dictionary : vocabulaire sur lequel l'embedding a été défini (gensim.corpora.dictionary.Dictionary)
        -gensim_model : un modèle gensim d'embedding (lsi, lda,...)
    Output: liste de liste de tuples (topic, coordonnée)
    """
    texts_test = [document for document in df_test[col_name]]
    corpus_test = [dictionary.doc2bow(text) for text in texts_test]
    tfidf_test = models.TfidfModel(corpus_test)
    vectors_test = tfidf[corpus_test]
    return gensim_model[vectors_test]

def embedding_formatting(embedded_texts, df_test, num_topics):
    """concatène le dataframe traité avec les coordonnées des textes représentés dans l'embedding
    Inputs:
        -embedded_texts : output de la fonction embedding
        -df_test: dataframe contenant les textes à "embedder"
        -num_topics : int: nombre de topics de l'embedding
    Output : copie du dataframe de départ, contenant les coordonnées des textes dans l'embedding
    """
    coords = pd.DataFrame(matutils.corpus2csc(embedded_texts).T.todense(),index=df_test.index.values)
    df_test2 = pd.concat([df_test, coords], axis=1, join='inner')
    df_test2.rename(columns=dict(zip(range(num_topics),['topic_'+str(i) for i in range(num_topics)])),inplace=True)
    return df_test2

def centroids(df_test, col_name):
    """ on calcule les barycentres de chaque famille Innoscape dans le système de coordonnées de l'embedding
    Inputs:
        -df_test: output de embedding_formatting
        -col_name : nom de la colonne contenant les familles produits
    """
    families = df_test[col_name].unique()
    centroids = df_test.groupby(col_name).mean()
    return centroids

def sq_distances(row, col_fam, col_list, centroids):
    """ on calcule enfin, pour chaque point, la distance au barycentre de sa famille"""
    label = row[col_fam]
    x = row[col_list]
    delta = (x-centroids.loc[label]).values
    return np.dot(delta, delta.T)

def get_sq_distances(num_topics, col_name, centroids, df_test ):
    col_list = ['topic_'+str(i) for i in range(num_topics)]
    df2 = df_test.copy()
    df2['distances'] = df2.apply(sq_distances, args=(col_name,col_list,centroids),axis=1)
    
    #calcul des distances moyennes
    avg_sq_dist = np.mean(df2['distances'])
    avg_sq_dist_by_fam = df2.groupby(col_name).mean()['distances']
    return(avg_sq_dist, avg_sq_dist_by_fam)
    
def eval_embedding(df_test, num_topics, text_col_name, fam_col_name, dictionary, gensim_model):
    embedded_texts = embedding(df_test, text_col_name, dictionary, gensim_model)
    formatted_embedding =  embedding_formatting(embedded_texts, df_test, num_topics)
    fam_centroids = centroids(formatted_embedding, fam_col_name)
    return get_sq_distances(num_topics, fam_col_name, fam_centroids, formatted_embedding)