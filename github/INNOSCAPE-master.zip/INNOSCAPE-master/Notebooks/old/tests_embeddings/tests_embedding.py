# -*- coding: utf-8 -*-
"""
Éditeur de Spyder

Ceci est un script temporaire.
"""

import pandas as pd
import numpy as np
from nltk.stem.snowball import SnowballStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from gensim.models import LsiModel
from gensim.models import ldamodel
import gensim.models as models
from sklearn.decomposition import NMF
from gensim import corpora

#%%

#création d'un dataframe test

documents=["Prier, prier, pleurer, gemir, est egalement lache",
      "Fais energiquement ta longue et lourde tache",
      "Dans la voie ou le sort a voulu te placer",
      "Puis, apres, comme moi, souffre et meurs sans parler"]

texts = [[word for word in document.lower().split()]
      for document in documents]

# remove words that appear only once
# =============================================================================
# from collections import defaultdict
# frequency = defaultdict(int)
# for text in texts:
#     for token in text:
#         frequency[token] += 1
# 
# texts = [[token for token in text if frequency[token] > 1]
#       for text in texts]
# =============================================================================

#%%

dictionary = corpora.Dictionary(texts)

new_doc = "rire parler prier kamoulox"
new_vec = dictionary.doc2bow(new_doc.lower().split())

#etape importante: transforme chaque texte en une liste de couples (indice_mot, nb_occurences_du_mot)
corpus = [dictionary.doc2bow(text) for text in texts]

#sauvegarde de l'objet corpus pour une utilisation future
#corpora.MmCorpus.serialize('C:/Users/JN/Desktop/Telecom ParisTech/Cours/INFMDI780 - Projet BigData/Notebooks/tmp/deerwester.mm', corpus)
#pour le récupérer, faire:
#corpus = corpora.MmCorpus('C:/Users/Pascal/Desktop/Telecom ParisTech/Cours/INFMDI780 - Projet BigData/Notebooks/tmp/deerwester.mm') # comes from the first tutorial, "From strings to vectors"

#%%
from gensim import corpora, models, similarities
lsi = models.LsiModel(corpus, id2word=dictionary, num_topics=15)

doc = "rire parler prier kamoulox"
vec_bow = dictionary.doc2bow(doc.lower().split())
vec_lsi = lsi[vec_bow] # convert the query to LSI space
print(vec_lsi)

#%%
#conversion du corpus dans la base de vecteurs propres issus de la lsi
corpus_lsi = lsi[corpus]