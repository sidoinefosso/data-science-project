from sklearn.ensemble import ExtraTreesClassifier
from sklearn.externals import joblib
import numpy as np

def categorization(X, y=None, thresholding='default', thresholds=None, mode='training' ,path="categorization_model", n_jobs=-1):
    """
    Fonction qui permet de:
    1) Entrainer un modèle de catégorisation à partir d'un training set et sauvegarder le modèle
    2) Charger un modèle et effectuer la prédiction
    
    Inputs:
        X : dataframe : matrice de features
        y : ndarray ou série pandas : labels
        mode : string : 'training' (entraîne et sauvegarde un classifieur) ou 'prediction' (applique un classifieur à X)
        path : string : chemin vers le répertoire où est stocké le classifieur
        n_jobs : int : nombre de threads pour le classifieur (ExtraTreeClassifier)
        thresholding : string : méthode pour déterminer le seuil de confiance sur les prédictions d'une famille. Si 'default', seuil unique fixé à 0.7 pour toutes les familles, si 'custom', passer un vecteur de seuils dans l'argument 'threshold'.
        thresholds : dict {label:threshold} : seuils à appliquer aux différentes familles pour considérer qu'une prédiction est fiable. La dimension doit être égale au nombre de familles.
        
    Outputs:
        hard_pred : ndarray : familles prédites par le classifieur 
        soft_pred : ndarray : prédictions d'appartenance à chaque famille
    """
    if mode == 'training':
        if y.any() == None:
            print("y n'a pas de valeur affecté.")
            return
        else:
            clf = ExtraTreesClassifier(n_estimators=100, random_state=2, n_jobs=n_jobs)
            clf.fit(X, y)
            joblib.dump(clf, path)
            return
        
    elif mode == 'prediction':
        clf = joblib.load(path)
        soft_pred = clf.predict_proba(X)
        hard_pred = clf.predict(X)
        return hard_pred, soft_pred
    
    else:
        print("Choisir un mode entre 'save' et 'load'.")
        return