import pandas as pd

def load_data(path_to_file, columns_to_keep=None):
    """
    Importation des données vendeurs à partir des colonnes sélectionnées et cleaning des données
    """
    if columns_to_keep == None:
        df_seller = pd.read_csv(path_to_file, sep = ",") # dataframe will all columns of csv
    else:
        df_seller = pd.read_csv(path_to_file, usecols=columns_to_keep, sep = ",") # dataframe with selected columns
    # On enlève les données il n'y a pas d'informations sur toute la ligne
    df_seller = df_seller.dropna(how='all', subset=df_seller.columns)
    # On remplace les NA par une valeur vide
    df_seller = df_seller.fillna("")
    return df_seller